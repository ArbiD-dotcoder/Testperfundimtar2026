class Femija {
    constructor(emri, mosha, grupi) {
        this.emri = emri;
        this.mosha = mosha;
        this.grupi = grupi;
    }

    shfaqTeDhenat() {
        console.log(`Emri: ${this.emri}`);
        console.log(`Mosha: ${this.mosha}`);
        console.log(`Grupi: ${this.grupi}`);
        console.log("----------------------");
    }
}

let femijet = [];

function regjistroFemije(emri, mosha, grupi) {
    let femijeRi = new Femija(emri, mosha, grupi);
    femijet.push(femijeRi);

    console.log(`Femija ${emri} u regjistrua me sukses!\n`);
}

function shfaqFemijet() {
    console.log("LISTA E FEMIJËVE");
    console.log("================");

    femijet.forEach(femije => {
        femije.shfaqTeDhenat();
    });
}

function kerkoFemije(emri) {
    let rezultati = femijet.find(f => f.emri === emri);

    if (rezultati) {
        console.log("Femija u gjet:");
        rezultati.shfaqTeDhenat();
    } else {
        console.log("Femija nuk ekziston.");
    }
}

let prezenca = [
    ["Ardi", "E Hënë", "Prezent"],
    ["Sara", "E Hënë", "Mungon"],
    ["Lina", "E Hënë", "Prezent"]
];

function shfaqPrezencen() {
    console.log("PREZENCA");
    console.log("=========");

    for (let i = 0; i < prezenca.length; i++) {
        console.log(
            `Emri: ${prezenca[i][0]}, Dita: ${prezenca[i][1]}, Statusi: ${prezenca[i][2]}`
        );
    }
}

regjistroFemije("Ardi", 5, "Grupi A");
regjistroFemije("Sara", 4, "Grupi B");
regjistroFemije("Lina", 5, "Grupi A");

shfaqFemijet();

kerkoFemije("Sara");

shfaqPrezencen();