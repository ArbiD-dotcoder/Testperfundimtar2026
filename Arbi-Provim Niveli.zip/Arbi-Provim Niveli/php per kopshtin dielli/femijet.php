<?php
session_start();

if(!isset($_SESSION['user'])) {
    header("Location: login.php");
}

// MATRICA / ARRAY
$femijet = array(

    array("Ana", 5, "Grupi A"),
    array("Leo", 4, "Grupi B"),
    array("Sara", 6, "Grupi A")

);

function shfaqFemije($matrica) {

    echo "<table border='1' cellpadding='10'>";

    echo "<tr>
            <th>Emri</th>
            <th>Mosha</th>
            <th>Grupi</th>
          </tr>";

    foreach($matrica as $femija) {

        $emri = strtoupper($femija[0]);

        echo "<tr>";

        echo "<td>".$emri."</td>";
        echo "<td>".$femija[1]."</td>";
        echo "<td>".$femija[2]."</td>";

        echo "</tr>";
    }

    echo "</table>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Femijët</title>
</head>
<body>

<h2>Kopshti Dielli</h2>

<p>
Përdoruesi:
<b>
<?php echo $_SESSION['user']; ?>
</b>
</p>

<?php

if(isset($_COOKIE['perdoruesi'])) {

    echo "Cookie aktiv për: ".$_COOKIE['perdoruesi']."<br><br>";
}

shfaqFemije($femijet);

?>

<br>

<a href="logout.php">Dil</a>

</body>
</html>