<?php
session_start();

if(isset($_SESSION['user'])) {
    header("Location: femijet.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Kopshti Dielli</title>
</head>
<body>

<h2>Mirësevini në Kopshtin Dielli</h2>

<a href="login.php">Hyr në sistem</a>

</body>
</html>