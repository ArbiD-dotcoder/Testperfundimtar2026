<?php
session_start();

if(isset($_POST['login'])) {

    $username = $_POST['username'];

    $_SESSION['user'] = $username;

    setcookie("perdoruesi", $username, time()+3600);

    header("Location: femijet.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>

<h2>Hyrje</h2>

<form method="POST">

    Emri:
    <input type="text" name="username" required>

    <br><br>

    <input type="submit" name="login" value="Hyr">

</form>

</body>
</html>